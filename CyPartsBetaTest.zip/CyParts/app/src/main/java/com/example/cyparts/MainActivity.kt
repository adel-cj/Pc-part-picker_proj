package com.example.cyparts

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.cyparts.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: PCPARTSDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            v.setPadding(
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).left,
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).top,
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).right,
                insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            )
            insets
        }

        dbHelper = PCPARTSDatabaseHelper(this)
        setupDropdown(binding.cpuDropdown, "CPUs")
        setupDropdown(binding.motherboardDropdown, "Motherboards")
        setupDropdown(binding.ramDropdown, "RAM")
        setupDropdown(binding.gpuDropdown, "GPUs")
        setupDropdown(binding.psuDropdown, "PowerSupplies")
        setupCompatibilityCheck()

        binding.clearAllButton.setOnClickListener { clearAllSelections() }
        binding.saveBuildButton.setOnClickListener { saveBuild() }
    }

    private fun setupDropdown(dropdown: AutoCompleteTextView, tableName: String) {
        try {
            val items = dbHelper.fetchDataFromDatabase(tableName, "model_name")
            if (items.isNotEmpty()) {
                val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, items)
                dropdown.setAdapter(adapter)
                dropdown.setOnClickListener { dropdown.showDropDown() }
            } else {
                dropdown.hint = "No compatible parts available"
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error loading data for $tableName: ${e.message}", Toast.LENGTH_SHORT).show()
            Log.e("MainActivity", "Error loading data for $tableName", e)
        }
    }

    private fun setupCompatibilityCheck() {
        val dropdowns = arrayOf(
            binding.cpuDropdown, binding.motherboardDropdown,
            binding.ramDropdown, binding.gpuDropdown, binding.psuDropdown
        )
        dropdowns.forEach { dropdown ->
            dropdown.onItemClickListener = AdapterView.OnItemClickListener { _, _, _, _ -> checkCompatibility() }
        }
    }

    private fun clearAllSelections() {
        binding.cpuDropdown.setText("", false)
        binding.motherboardDropdown.setText("", false)
        binding.ramDropdown.setText("", false)
        binding.gpuDropdown.setText("", false)
        binding.psuDropdown.setText("", false)
        updateCompatibilityUI("", R.color.black, false)
        Toast.makeText(this, "Selections cleared!", Toast.LENGTH_SHORT).show()
    }

    private fun saveBuild() {
        val selectedCPU = binding.cpuDropdown.text.toString()
        val selectedMotherboard = binding.motherboardDropdown.text.toString()
        val selectedRAM = binding.ramDropdown.text.toString()
        val selectedGPU = binding.gpuDropdown.text.toString()
        val selectedPSU = binding.psuDropdown.text.toString()

        if (listOf(selectedCPU, selectedMotherboard, selectedRAM, selectedGPU, selectedPSU).any { it.isEmpty() }) {
            Toast.makeText(this, "Please select all parts before saving.", Toast.LENGTH_SHORT).show()
            return
        }

        val success = dbHelper.saveBuildToDatabase(selectedCPU, selectedMotherboard, selectedRAM, selectedGPU, selectedPSU)
        Toast.makeText(this, if (success) "Build saved successfully!" else "Failed to save build.", Toast.LENGTH_SHORT).show()
    }

    private fun checkCompatibility() {
        val selectedCPU = binding.cpuDropdown.text.toString()
        val selectedMotherboard = binding.motherboardDropdown.text.toString()
        val selectedRAM = binding.ramDropdown.text.toString()
        val selectedGPU = binding.gpuDropdown.text.toString()
        val selectedPSU = binding.psuDropdown.text.toString()

        if (listOf(selectedCPU, selectedMotherboard, selectedRAM, selectedGPU, selectedPSU).any { it.isEmpty() }) {
            updateCompatibilityUI("Please select all parts to check compatibility.", R.color.orange, false)
            return
        }

        val errors = mutableListOf<String>()

        dbHelper.isCpuCompatibleWithMotherboard(selectedCPU, selectedMotherboard)?.let { errors.add(it) }
        dbHelper.isRamCompatibleWithMotherboard(selectedRAM, selectedMotherboard)?.let { errors.add(it) }
        dbHelper.isGpuCompatibleWithPsu(selectedGPU, selectedPSU)?.let { errors.add(it) }

        if (errors.isEmpty()) {
            updateCompatibilityUI("All parts are compatible!", R.color.green, true)
        } else {
            updateCompatibilityUI(errors.joinToString("\n"), R.color.red, false)
        }
    }

    private fun updateCompatibilityUI(message: String, messageColor: Int, isCompatible: Boolean) {
        binding.compatibilityStatus.text = message
        binding.compatibilityStatus.setTextColor(resources.getColor(messageColor, theme))

        if (isCompatible) {
            binding.finalCompatibilityIndicator.text = "Your build is fully compatible!"
            binding.finalCompatibilityIndicator.setBackgroundColor(resources.getColor(R.color.green, theme))
            binding.finalCompatibilityIndicator.visibility = View.VISIBLE
        } else {
            binding.finalCompatibilityIndicator.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        dbHelper.close()
        super.onDestroy()
    }
}
