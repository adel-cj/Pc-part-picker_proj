package com.example.cyparts

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class PCPARTSDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val TAG = "PCPARTSDatabaseHelper"
        private const val DATABASE_NAME = "pcparts.db"
        private const val DATABASE_VERSION = 8
    }

    override fun onCreate(db: SQLiteDatabase) {
        Log.d(TAG, "Creating database tables...")

        val createTables = arrayOf(
            """CREATE TABLE CPUs (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                model_name TEXT NOT NULL, 
                socket_type TEXT NOT NULL, 
                compatibility_key TEXT NOT NULL, 
                core_count INTEGER NOT NULL, 
                clock_speed REAL NOT NULL
            );""",
            """CREATE TABLE Motherboards (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                model_name TEXT NOT NULL, 
                socket_type TEXT NOT NULL, 
                compatibility_key TEXT NOT NULL, 
                chipset TEXT NOT NULL, 
                ram_type TEXT NOT NULL, 
                ram_slots INTEGER NOT NULL, 
                max_ram INTEGER NOT NULL
            );""",
            """CREATE TABLE RAM (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                model_name TEXT NOT NULL, 
                type TEXT NOT NULL, 
                compatibility_key TEXT NOT NULL, 
                capacity INTEGER NOT NULL, 
                speed INTEGER NOT NULL
            );""",
            """CREATE TABLE GPUs (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                model_name TEXT NOT NULL, 
                memory_size INTEGER NOT NULL, 
                interface_type TEXT NOT NULL, 
                compatibility_key TEXT NOT NULL,
                power_requirement INTEGER NOT NULL
            );""",
            """CREATE TABLE PowerSupplies (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                model_name TEXT NOT NULL, 
                compatibility_key TEXT NOT NULL, 
                wattage INTEGER NOT NULL
            );""",
            """CREATE TABLE IF NOT EXISTS SavedBuilds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cpu TEXT,
                motherboard TEXT,
                ram TEXT,
                gpu TEXT,
                psu TEXT
            );"""
        )

        createTables.forEach { db.execSQL(it) }
        Log.d(TAG, "Tables created successfully.")
        seedData(db)
    }

    private fun seedData(db: SQLiteDatabase) {
        try {
            Log.d(TAG, "Seeding initial data...")

            val seedQueries = arrayOf(
                """INSERT INTO CPUs (model_name, socket_type, compatibility_key, core_count, clock_speed) VALUES
            ('Intel Core i7-12700K', 'LGA1700', 'LGA1700', 12, 3.6),
            ('AMD Ryzen 7 5800X', 'AM4', 'AM4', 8, 3.8),
            ('Intel Core i9-12900K', 'LGA1700', 'LGA1700', 16, 3.2),
            ('AMD Ryzen 9 5900X', 'AM4', 'AM4', 12, 3.7),
            ('Intel Core i5-12600K', 'LGA1700', 'LGA1700', 10, 3.7),
            ('AMD Ryzen 5 5600X', 'AM4', 'AM4', 6, 3.7),
            ('Intel Core i3-12100F', 'LGA1700', 'LGA1700', 4, 3.3),
            ('AMD Ryzen 3 3300X', 'AM4', 'AM4', 4, 3.8),
            ('Intel Core i7-11700K', 'LGA1200', 'LGA1200', 8, 3.6),
            ('AMD Ryzen 7 3700X', 'AM4', 'AM4', 8, 3.6),
            ('Intel Core i9-11900K', 'LGA1200', 'LGA1200', 8, 3.5);
            """,
                """INSERT INTO Motherboards (model_name, socket_type, compatibility_key, chipset, ram_type, ram_slots, max_ram) VALUES
            ('ASUS ROG STRIX Z690-A', 'LGA1700', 'LGA1700', 'Z690', 'DDR4', 4, 128),
            ('MSI MPG B550 GAMING PLUS', 'AM4', 'AM4', 'B550', 'DDR4', 4, 128),
            ('Gigabyte Z690 AORUS ELITE', 'LGA1700', 'LGA1700', 'Z690', 'DDR5', 4, 128),
            ('ASUS TUF GAMING B550-PLUS', 'AM4', 'AM4', 'B550', 'DDR4', 4, 128),
            ('MSI Z590 PRO WIFI', 'LGA1200', 'LGA1200', 'Z590', 'DDR4', 4, 128),
            ('Gigabyte B450 AORUS ELITE', 'AM4', 'AM4', 'B450', 'DDR4', 4, 64),
            ('ASRock B560M PRO4', 'LGA1200', 'LGA1200', 'B560', 'DDR4', 4, 64),
            ('MSI MEG X570 UNIFY', 'AM4', 'AM4', 'X570', 'DDR4', 4, 128),
            ('ASUS PRIME H570M-PLUS', 'LGA1200', 'LGA1200', 'H570', 'DDR4', 2, 64),
            ('Gigabyte X570 AORUS MASTER', 'AM4', 'AM4', 'X570', 'DDR4', 4, 128),
            ('ASRock Z490 Phantom Gaming 4', 'LGA1200', 'LGA1200', 'Z490', 'DDR4', 4, 128);
            """,
                """INSERT INTO RAM (model_name, type, compatibility_key, capacity, speed) VALUES
            ('Corsair Vengeance LPX 16GB', 'DDR4', 'DDR4', 16, 3200),
            ('G.SKILL Trident Z RGB 32GB', 'DDR4', 'DDR4', 32, 3600),
            ('Crucial Ballistix 16GB', 'DDR4', 'DDR4', 16, 3000),
            ('Kingston Fury Beast 16GB', 'DDR4', 'DDR4', 16, 3600),
            ('Corsair Dominator Platinum 32GB', 'DDR4', 'DDR4', 32, 3200),
            ('G.SKILL Ripjaws V 8GB', 'DDR4', 'DDR4', 8, 2666),
            ('Team T-Force Delta RGB 16GB', 'DDR4', 'DDR4', 16, 3600),
            ('ADATA XPG Spectrix D60G 16GB', 'DDR4', 'DDR4', 16, 3200),
            ('Patriot Viper Steel 16GB', 'DDR4', 'DDR4', 16, 4400),
            ('Samsung 16GB DDR4', 'DDR4', 'DDR4', 16, 2666),
            ('HyperX Predator 32GB', 'DDR4', 'DDR4', 32, 4000);
            """,
                """INSERT INTO GPUs (model_name, memory_size, interface_type, compatibility_key, power_requirement) VALUES
            ('NVIDIA GeForce RTX 3090', 24, 'PCIe 4.0', 'PCIe', 350),
            ('AMD Radeon RX 6900 XT', 16, 'PCIe 4.0', 'PCIe', 300),
            ('NVIDIA GeForce RTX 3080', 10, 'PCIe 4.0', 'PCIe', 320),
            ('AMD Radeon RX 6800 XT', 16, 'PCIe 4.0', 'PCIe', 280),
            ('NVIDIA GeForce RTX 3070', 8, 'PCIe 4.0', 'PCIe', 220),
            ('AMD Radeon RX 6700 XT', 12, 'PCIe 4.0', 'PCIe', 230),
            ('NVIDIA GeForce RTX 3060 Ti', 8, 'PCIe 4.0', 'PCIe', 200),
            ('AMD Radeon RX 6600 XT', 8, 'PCIe 4.0', 'PCIe', 160),
            ('NVIDIA GeForce GTX 1660 Super', 6, 'PCIe 3.0', 'PCIe', 125),
            ('AMD Radeon RX 580', 8, 'PCIe 3.0', 'PCIe', 185),
            ('NVIDIA GeForce RTX 3050', 8, 'PCIe 4.0', 'PCIe', 130);

            """,
                """INSERT INTO PowerSupplies (model_name, compatibility_key, wattage) VALUES
            ('Corsair RM850x', 'PCIe', 850),
            ('EVGA SuperNOVA 750W', 'PCIe', 750),
            ('Seasonic Focus GX-650', 'PCIe', 650),
            ('Cooler Master MWE 550W', 'PCIe', 550),
            ('Thermaltake Smart 700W', 'PCIe', 700),
            ('Corsair CX 650M', 'PCIe', 650),
            ('EVGA 600 W1', 'PCIe', 600),
            ('ASUS ROG Strix 750W', 'PCIe', 750),
            ('Seasonic PRIME TX-1000', 'PCIe', 1000),
            ('Gigabyte P750GM', 'PCIe', 750),
            ('Cooler Master V850', 'PCIe', 850);
            """
            )

            seedQueries.forEach { db.execSQL(it) }
            Log.d(TAG, "Data seeding completed.")
        } catch (e: Exception) {
            Log.e(TAG, "Error seeding data: ${e.message}")
        }
    }


    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Log.d(TAG, "Upgrading database from version $oldVersion to $newVersion")

        val tables = arrayOf("CPUs", "Motherboards", "RAM", "GPUs", "PowerSupplies", "SavedBuilds")
        tables.forEach { db.execSQL("DROP TABLE IF EXISTS $it") }

        onCreate(db)
    }


    fun isCpuCompatibleWithMotherboard(cpu: String, motherboard: String): String {
        val cpuSocket = getFieldValue("CPUs", "socket_type", cpu)
        val motherboardSocket = getFieldValue("Motherboards", "socket_type", motherboard)

        return if (cpuSocket == motherboardSocket) {
            "CPU and Motherboard are compatible."
        } else {
            "Incompatible! CPU socket type ($cpuSocket) does not match Motherboard socket type ($motherboardSocket)."
        }
    }


    fun isRamCompatibleWithMotherboard(ram: String, motherboard: String): String {
        val motherboardRamType = getFieldValue("Motherboards", "ram_type", motherboard)
        val ramType = getFieldValue("RAM", "type", ram)

        return if (motherboardRamType == ramType) {
            "RAM is compatible with the Motherboard."
        } else {
            "Incompatible! RAM type ($ramType) does not match Motherboard RAM type ($motherboardRamType)."
        }
    }


    fun isGpuCompatibleWithPsu(gpu: String, psu: String): String {
        val gpuPowerRequirement = getFieldValue("GPUs", "power_requirement", gpu)?.toIntOrNull() ?: 0
        val psuWattage = getFieldValue("PowerSupplies", "wattage", psu)?.toIntOrNull() ?: 0

        return if (psuWattage >= gpuPowerRequirement) {
            "PSU provides enough power for the GPU."
        } else {
            "Incompatible! GPU requires $gpuPowerRequirement W but PSU only provides $psuWattage W."
        }
    }
    fun checkBuildCompatibility(cpu: String, motherboard: String, ram: String, gpu: String, psu: String): String {
        val cpuResult = isCpuCompatibleWithMotherboard(cpu, motherboard)
        val ramResult = isRamCompatibleWithMotherboard(ram, motherboard)
        val gpuResult = isGpuCompatibleWithPsu(gpu, psu)

        if (cpuResult.contains("compatible") && ramResult.contains("compatible") && gpuResult.contains("compatible")) {
            return "All parts are compatible. Your build is complete."
        }

        val issues = mutableListOf<String>()
        if (!cpuResult.contains("compatible")) {
            val suggestedCpu = fetchCompatiblePart("CPUs", "socket_type", getFieldValue("Motherboards", "socket_type", motherboard)!!)
            issues.add("CPU issue: $cpuResult. Suggested alternative: $suggestedCpu")
        }
        if (!ramResult.contains("compatible")) {
            val suggestedRam = fetchCompatiblePart("RAM", "type", getFieldValue("Motherboards", "ram_type", motherboard)!!)
            issues.add("RAM issue: $ramResult. Suggested alternative: $suggestedRam")
        }
        if (!gpuResult.contains("compatible")) {
            val suggestedPsu = fetchCompatiblePart("PowerSupplies", "wattage", gpuResult.filter { it.isDigit() }.toInt().toString())
            issues.add("GPU issue: $gpuResult. Suggested alternative: $suggestedPsu")
        }

        return issues.joinToString("\n")
    }

    private fun fetchCompatiblePart(tableName: String, columnName: String, value: String): String {
        val db = readableDatabase
        var compatiblePart = "No compatible alternative found."
        try {
            val cursor = db.rawQuery("SELECT model_name FROM $tableName WHERE $columnName = ? LIMIT 1", arrayOf(value))
            if (cursor.moveToFirst()) {
                compatiblePart = cursor.getString(cursor.getColumnIndexOrThrow("model_name"))
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching compatible part from $tableName: ${e.message}")
        } finally {
            db.close()
        }
        return compatiblePart
    }



    fun saveBuildToDatabase(cpu: String, motherboard: String, ram: String, gpu: String, psu: String): Boolean {
        return try {
            val db = writableDatabase
            val query = "INSERT INTO SavedBuilds (cpu, motherboard, ram, gpu, psu) VALUES (?, ?, ?, ?, ?)"
            val statement = db.compileStatement(query)
            statement.bindString(1, cpu)
            statement.bindString(2, motherboard)
            statement.bindString(3, ram)
            statement.bindString(4, gpu)
            statement.bindString(5, psu)
            statement.executeInsert()
            db.close()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving build: ${e.message}")
            false
        }
    }


    fun fetchDataFromDatabase(tableName: String, columnName: String): List<String> {
        val db = readableDatabase
        val parts = mutableListOf<String>()
        try {
            val cursor = db.rawQuery("SELECT $columnName FROM $tableName", null)
            while (cursor.moveToNext()) {
                parts.add(cursor.getString(cursor.getColumnIndexOrThrow(columnName)))
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching data from $tableName: ${e.message}")
        } finally {
            db.close()
        }
        return parts
    }



    private fun getFieldValue(tableName: String, fieldName: String, modelName: String): String? {
        val db = readableDatabase
        var value: String? = null
        try {
            val cursor = db.rawQuery("SELECT $fieldName FROM $tableName WHERE model_name = ?", arrayOf(modelName))
            if (cursor.moveToFirst()) {
                value = cursor.getString(cursor.getColumnIndexOrThrow(fieldName))
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching $fieldName from $tableName: ${e.message}")
        }
        return value
    }
}
