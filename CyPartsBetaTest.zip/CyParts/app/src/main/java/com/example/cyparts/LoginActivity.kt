package com.example.cyparts

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cyparts.databinding.ActivityLoginBinding
import databaseHelper

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var databaseHelper: databaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        databaseHelper = databaseHelper(this)
        binding.loginButton.setOnClickListener {
            val email = binding.loginemail.text.toString().trim()
            val password = binding.loginpassword.text.toString().trim()
            loginDatabase(email, password)


        }
        binding.signupRedirect.setOnClickListener{
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
    private fun loginDatabase(email: String, password: String) {
        val userExists = databaseHelper.readUser(email, password)
        if (userExists){
            Toast.makeText(this,"Log in Successful", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }else{
            Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show()
        }


    }
}
