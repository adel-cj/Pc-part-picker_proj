package com.example.cyparts

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cyparts.databinding.ActivitySignupBinding
import databaseHelper


class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var databaseHelper: databaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = databaseHelper(this)

        binding.signupButton.setOnClickListener {

            val email = binding.signupemail.text.toString().trim()
            val password = binding.signuppassword.text.toString().trim()
            val firstName = binding.firstname.text.toString().trim()
            val lastName = binding.Lastname.text.toString().trim()
            val middleInitial = binding.middleInitial.text.toString().trim()
            val dateOfBirth = binding.dateOfBirth.text.toString().trim()


            if (email.isNotEmpty() && password.isNotEmpty() && firstName.isNotEmpty() && lastName.isNotEmpty()) {

                signupDatabase(email, password, firstName, lastName, middleInitial, dateOfBirth)
            } else {

                Toast.makeText(this, "Please fill out all required fields.", Toast.LENGTH_SHORT).show()
            }
            binding.loginRedirect.setOnClickListener{
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        }


    }
    private fun signupDatabase(email: String, password: String, firstName: String, lastName: String, middleInitial: String, dateOfBirth: String) {
        val insertedRowId = databaseHelper.insertUser(
            email = email,
            password = password,
            firstName = firstName,
            lastName = lastName,
            middleInitial = middleInitial,
            dateOfBirth = dateOfBirth
        )
        if (insertedRowId != -1L){
            Toast.makeText(this, "Signup Successful", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()

        }else{
            Toast.makeText(this, "Signup FAiled", Toast.LENGTH_SHORT).show()
        }
    }
}